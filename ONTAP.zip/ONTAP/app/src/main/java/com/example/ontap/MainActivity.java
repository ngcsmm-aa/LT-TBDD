package com.example.ontap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    RadioGroup group;
    RadioButton manhinh2,manhinh3;
    Button btn_chuyen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manhinh2=findViewById(R.id.manhinh2);
        manhinh3=findViewById(R.id.manhinh3);
        btn_chuyen=findViewById(R.id.btn_chuyen);
        group=findViewById(R.id.group);

        btn_chuyen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int chuyen=group.getCheckedRadioButtonId();
                if (chuyen==R.id.manhinh2){
                    Intent intent =new Intent(MainActivity.this,MainActivity2.class);
                    startActivity(intent);
                }else{
                    Intent intent =new Intent(MainActivity.this,MainActivity3.class);
                    startActivity(intent);
                }
            }
        });
//        btn_chuyen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if ( manhinh2.isChecked()){
//                    Intent intent =new Intent(MainActivity.this,MainActivity2.class);
//                    startActivity(intent);
//                } else if (manhinh3.isChecked()) {
//                    Intent intent =new Intent(MainActivity.this,MainActivity3.class);
//                    startActivity(intent);
//
//                }
//            }
//        });

    }
}