package com.example.ontap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView tv_kq=(TextView) findViewById(R.id.tv_kq);
        TextView tv_nhap=(TextView) findViewById(R.id.tv_nhap);
        EditText nhap=(EditText) findViewById(R.id.nhap);
        Button them=(Button) findViewById(R.id.them);
        Button scp=(Button) findViewById(R.id.scp);
        Button snt=(Button) findViewById(R.id.snt);
        Button thoat=(Button) findViewById(R.id.thoat);
        ArrayList<Integer> arrayList=new ArrayList<>(10);
        ArrayList<Integer> tempList = new ArrayList<>();

        //Nhập mảng
        them.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int gt=0;
                gt= Integer.parseInt(nhap.getText().toString());
                arrayList.add(gt);
                int size=arrayList.size();
                String st="";
                for (int i=0; i<size;i++){
                    st+=arrayList.get(i).toString()+" ";
                }
                tv_nhap.setText(st.toString());
            }
        });

        scp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tempList.clear();
                tempList.addAll(arrayList);
                int size=tempList.size();
                String st="";
                for (int i=0; i<size;i++){
                    if(scp(tempList.get(i))){
                        st+=tempList.get(i).toString()+" ";
                    }
                }
                tv_kq.setText(st);
            }
        });

        //THÊM SỐ NGUYÊN TỐ

        thoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(MainActivity2.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    //Số chính phương
    public boolean scp (int a){
        int b=(int)Math.sqrt(a);
        return b*b==a;
    }

    //Số nguyên tố
    public boolean snt(int a){
        if (a<2){
            return false;
        }
        for (int i=2;i<=Math.sqrt(a);i++){
            if (a%i==0){
                return false;
            }
        }return true;
    }
}