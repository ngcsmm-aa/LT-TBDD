package com.example.ontap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import java.util.ArrayList;


public class MainActivity3 extends AppCompatActivity {

    SQLiteDatabase mydatabase;
    ArrayList<String> mylist=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        EditText ed_ma=(EditText) findViewById(R.id.ed_ma);
        EditText ed_ten=(EditText) findViewById(R.id.ed_ten);
        RadioGroup group_mau=(RadioGroup) findViewById(R.id.group_mau);
        RadioButton mau_xanh=(RadioButton) findViewById(R.id.mau_xanh);
        RadioButton mau_vang=(RadioButton) findViewById(R.id.mau_vang);
        Button them_csdl=(Button) findViewById(R.id.them_csdl);
        ListView listView=(ListView) findViewById(R.id.listview);

        ArrayAdapter<String>adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,mylist);
        listView.setAdapter(adapter);
        mydatabase=openOrCreateDatabase("qls.db",MODE_PRIVATE,null);
        try{
            String sql="CREATE TABLE sach ( ed_ma TEXT primary key, ed_ten TEXT, mau TEXT)";
            mydatabase.execSQL(sql);
        }catch (Exception e){}
        them_csdl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ma=ed_ma.getText().toString();
                String ten=ed_ten.getText().toString();
                int vt=group_mau.getCheckedRadioButtonId();
                RadioButton mau=findViewById(vt);
                String color=mau.getText().toString();
                ContentValues values = new ContentValues();
                values.put("ed_ma",ma);
                values.put("ed_ten",ten);
                values.put("mau",color);
                String msg="";
                if (mydatabase.insert("sach",null,values)==-1){
                    msg="Lỗi!!!!";
                }else {
                    msg="Thêm thành cônggggggggggg";
                }
                Toast.makeText(MainActivity3.this,msg,Toast.LENGTH_LONG).show();
                mylist.clear();
                Cursor c=mydatabase.query("sach",null,null,null,null,null,null);
                c.moveToFirst();
                String data="";
                while(c.isAfterLast()==false){
                   data="Mã sách: "+c.getString(0) +"\n Tên sách: "+c.getString(1)+"\n Màu: "+c.getString(2);
                    c.moveToNext();
                    mylist.add(data);
                }
                c.close();
                adapter.notifyDataSetChanged();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedData = mylist.get(i);
                String[] parts = selectedData.split("\n");
                String ma = parts[0].substring(parts[0].indexOf(":") + 2);
                mydatabase.delete("sach","ed_ma=?", new String[]{ma});
                mylist.remove(i);
                adapter.notifyDataSetChanged();

            return true;}
        });


    }
}